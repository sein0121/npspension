package com.nps.pension.dao;

public interface NpsPen0002DAO {
}
